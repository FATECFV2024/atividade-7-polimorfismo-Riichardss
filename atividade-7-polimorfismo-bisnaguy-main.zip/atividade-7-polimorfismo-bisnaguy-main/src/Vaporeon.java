public class Vaporeon extends Eevee {
    
    @Override
    public String ataque(){
        return "Jato d'Água";
    }
    
    @Override
    public String defesa(){
        return "Escudo Aquático";
    }

    @Override
    public String especial(){
        return "Hidrobomba";
    }
}
