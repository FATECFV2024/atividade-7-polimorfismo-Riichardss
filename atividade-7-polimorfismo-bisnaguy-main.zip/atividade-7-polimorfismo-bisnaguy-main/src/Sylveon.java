public class Sylveon extends Eevee {
    
    @Override
    public String ataque(){
        return "Beijo Místico";
    }
    
    @Override
    public String defesa(){
        return "Proteção Encantada";
    }

    @Override
    public String especial(){
        return "Poder da Fada";
    }
}
