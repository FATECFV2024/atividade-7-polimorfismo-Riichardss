public class Flareon extends Eevee {
    
    @Override
    public String ataque(){
        return "Ataque de Fogo";
    }
    
    @Override
    public String defesa(){
        return "Defesa Ardente";
    }

    @Override
    public String especial(){
        return "Lança-Chamas";
    }
}
