public class Glaceon extends Eevee {
    
    @Override
    public String ataque(){
        return "Rajada de Gelo";
    }
    
    @Override
    public String defesa(){
        return "Escudo de Gelo";
    }

    @Override
    public String especial(){
        return "Tempestade de Gelo";
    }
}
