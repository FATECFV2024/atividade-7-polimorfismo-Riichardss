public class Umbreon extends Eevee {
    
    @Override
    public String ataque(){
        return "Ataque Sombrio";
    }
    
    @Override
    public String defesa(){
        return "Escudo Noturno";
    }

    @Override
    public String especial(){
        return "Olhar Tenebroso";
    }
}
