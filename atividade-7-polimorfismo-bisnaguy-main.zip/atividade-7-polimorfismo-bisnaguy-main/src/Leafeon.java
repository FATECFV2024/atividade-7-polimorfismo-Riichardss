public class Leafeon extends Eevee {
    
    @Override
    public String ataque(){
        return "Chicote de Vinha";
    }
    
    @Override
    public String defesa(){
        return "Escudo de Folhas";
    }

    @Override
    public String especial(){
        return "Raio Solar";
    }
}
