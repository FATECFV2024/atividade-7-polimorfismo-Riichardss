public class Pokedex {
    public static void main(String[] args) throws Exception {
        
        Eevee e1 = new Eevee();
        Espeon es1 = new Espeon();
        Flareon fl1 = new Flareon();
        Glaceon gl1 = new Glaceon();
        Jolteon j1 = new Jolteon();
        Leafeon l1 = new Leafeon();
        Sylveon sl1 = new Sylveon();
        Umbreon um1 = new Umbreon();
        Vaporeon va1 = new Vaporeon();

        System.out.println("Ataque: "+e1.ataque());
        System.out.println("Defesa: "+e1.defesa());
        System.out.println("Especial: "+e1.especial()+"\n");

        e1=es1;

        System.out.println("Ataque: "+e1.ataque());
        System.out.println("Defesa: "+e1.defesa());
        System.out.println("Especial: "+e1.especial()+"\n");
        
        e1=fl1;

        System.out.println("Ataque: "+e1.ataque());
        System.out.println("Defesa: "+e1.defesa());
        System.out.println("Especial: "+e1.especial()+"\n");

        e1=gl1;

        System.out.println("Ataque: "+e1.ataque());
        System.out.println("Defesa: "+e1.defesa());
        System.out.println("Especial: "+e1.especial()+"\n");

        e1=j1;

        System.out.println("Ataque: "+e1.ataque());
        System.out.println("Defesa: "+e1.defesa());
        System.out.println("Especial: "+e1.especial()+"\n");

        e1=l1;

        System.out.println("Ataque: "+e1.ataque());
        System.out.println("Defesa: "+e1.defesa());
        System.out.println("Especial: "+e1.especial()+"\n");

        e1=sl1;

        System.out.println("Ataque: "+e1.ataque());
        System.out.println("Defesa: "+e1.defesa());
        System.out.println("Especial: "+e1.especial()+"\n");
        
        e1=um1;

        System.out.println("Ataque: "+e1.ataque());
        System.out.println("Defesa: "+e1.defesa());
        System.out.println("Especial: "+e1.especial()+"\n");
        
        e1=va1;

        System.out.println("Ataque: "+e1.ataque());
        System.out.println("Defesa: "+e1.defesa());
        System.out.println("Especial: "+e1.especial()+"\n");

        

        
    }
}
