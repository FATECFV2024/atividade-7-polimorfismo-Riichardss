public class Eevee{
    String tipo;
    double peso;
    int altura;
    int hp; //Healt Point
    String subtipo;

    public String ataque(){
        return "Ataque rápido";
    }

    public String defesa(){
        return "Desvio";
    }

    public String especial(){
        return "Tri-ataque";
    }
}