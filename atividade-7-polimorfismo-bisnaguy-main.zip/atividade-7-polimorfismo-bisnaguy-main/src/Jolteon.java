public class Jolteon extends Eevee {
    
    @Override
    public String ataque(){
        return "Trovoada - Thunder Shock";
    }
    
    @Override
    public String defesa(){
        return "Carga - Wild Charge";
    }

    @Override
    public String especial(){
        return "Raio - Thunderbolt";
    }
}
