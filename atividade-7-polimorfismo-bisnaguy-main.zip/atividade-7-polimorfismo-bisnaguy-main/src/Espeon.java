public class Espeon extends Eevee {
    
    @Override
    public String ataque(){
        return "Raio Psíquico";
    }
    
    @Override
    public String defesa(){
        return "Proteção Mental";
    }

    @Override
    public String especial(){
        return "Psíquico";
    }
}
